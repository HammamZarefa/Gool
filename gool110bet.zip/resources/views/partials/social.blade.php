<div class="col-md-6">
    
    <ul class="socials">
        <li><a href="https://www.facebook.com/AllSafeMHR" target="_blank" class="facebook"><i class="fab fa-facebook-f"></i></a></li>
        <li>
            <a href="https://www.facebook.com/profile.php?id=100024078789278"  target="_blank" class="twitter">
                <i class="fab fa-twitter"></i>
            </a>
        </li>
        <li><a href="http://www.linkedin.com/shareArticle?mini=true&url={{urlencode(url('/'))}}" target="_blank" class="linkedin"><i class="fab fa-linkedin-in"></i></a></li>
        <li><a href="https://www.facebook.com/AllSafeP" target="_blank" class="pinterest"><i class="fab fa-pinterest"></i></a></li>
        <li><a href="https://wa.me/message/4F4HZ2TN6NN5K1" target="_blank" class="whatsapp"><i class="fab fa-whatsapp"></i></a></li>
        
    </ul>
</div>
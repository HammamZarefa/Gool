<div class="col-md-6"  style="margin-inline-start: auto;">
    <ul class="socials text-end">
        <li><a href="{{route('lang','en')}}"  class=""><img src="{{asset('images/icons/enflag.png')}}"> </a></li>
        <li><a href="{{route('lang','ar')}}" class=""><img src="{{asset('images/icons/iraqflag.png')}}"></a></li>
        <li><a href="{{route('lang','tr')}}"  class=""><img src="{{asset('images/icons/trflag.png')}}"></a></li>
    </ul>
</div>
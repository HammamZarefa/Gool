@extends('layout2')
@section('content')
    <div align="center" style="min-width: 1200px;">


        <div id="leftpanel" style="display: inline-block; float: left; width: 220px; padding-top:20px">
            <table width="220" height="150" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td width="100%" valign="top">
                        <div id='cssmenu'>
                            <ul>
                                <li class='active'><a href='#'><span>Favorites</span></a></li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','ft199.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/ft199.png" height="24px" width="30px"></span></a>
                                                </td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','ft199.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">UEFA
                                                        Championship</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','ft199.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/ft199.png" height="24px" width="30px"></span></a>
                                                </td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','ft199.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">UEFA
                                                        Europe League</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','195.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/195.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','195.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Turkey
                                                        Super League</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','117.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/117.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','117.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">England
                                                        Premier League</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','109.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/109.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','109.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Spain
                                                        LaLiga</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','41.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/41.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','41.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Germany
                                                        Bundesliga</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','107.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/107.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','107.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Italy
                                                        Serie A</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','110.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/110.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','110.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">France
                                                        Ligue 1</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','f32.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/f32.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','f32.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Holland
                                                        Eerste Divisie</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                                <li class='has-sub' active>
                                    <ul style="display: block; border-right:0px; border-left:0px">
                                        <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                               style="background: url(../img/menubck.png) #000;">
                                            <tr>
                                                <td align="center" valign="bottom" width="36px" height="24px"><a
                                                            href='#'
                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','f72.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                    src="../flags/f72.png" height="24px"
                                                                    width="30px"></span></a></td>
                                                <td width="214px" style="padding-left:10px"><a href='#'
                                                                                               onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','f72.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                                               style="padding-top: 0px; font-weight:100"
                                                                                               data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Belgium
                                                        Pro Ligue</a></td>
                                            </tr>
                                        </table>
                                    </ul>
                                </li>

                            </ul>
                        </div>
                        <div id='cssmenu'>
                            <ul>
                                <li class='active'><a href='#'><span>Sports Bets</span></a></li>
                                <li class='has-sub active'>
                                    <a href='#'><span style="background: url(images/icon_soccer.png) center no-repeat;">
				   <table width="100%">

				   <tr>
					   <td style="padding-left: 25px;">كرة القدم</td>
					   <td width="30" style="text-align: right; font-size: 14px;">503</td>
				   </tr>
				   </table>
			   </span></a>
                                    <ul style="display: block">
                                        @foreach(\App\Sport::all() as $sport)
                                            @if($sport->sport='كرة القدم')
                                        <li>
                                            <table width="100%" border="0" cellspacing="0" cellpadding="0"
                                                   style="background: url(../img/menubck.png) #000;">
                                                <tr>
                                                    <td align="center" valign="bottom" width="36px" height="24px"><a
                                                                href='#'
                                                                onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','vietnam.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                data-cf-modified-49a1a8758d1ec0bbde0e32af-=""><span><img
                                                                        src="https://cdn.o-betgaming.com/lflags/vietnam.png"
                                                                        height="16px" width="20px"></span></a></td>
                                                    <td width="150px"><a href='#'
                                                                         onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','vietnam.png','1','F',document.forms['test2'].takad.value);togglek('nextbets');"
                                                                         style="padding-top: 0px;"
                                                                         data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Vietnam</a>
                                                    </td>
                                                    <td width="40px" style="color:#FFF;font-size: 14px;">4</td>
                                                    <td width="24px"><input type="checkbox" name="ulke" id="ulke"
                                                                            value="TR"
                                                                            onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','vietnam.png',document.getElementById('ulke').checked,'F',document.forms['test2'].takad.value);"
                                                                            data-cf-modified-49a1a8758d1ec0bbde0e32af-="">
                                                    </td>
                                                </tr>
                                            </table>
                                        </li>
                                            @endif
                                            @endforeach
                                    </ul>
                                </li>

                            </ul>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <div id="centerpanel"
             style="display: inline-block; width: calc(100% - 460px); min-width: 740px; padding-top:20px">
            <form id="test2" name="test2">
                <table border="0" cellspacing="0" cellpadding="0" width="100%">
                    <tr style="text-align: center; background-color: #000000;">
                        <td bgcolor="#000000">
                            <div id="trcanlitv" style="text-align: center; display: none">
                                <table border="0" width="100%" cellspacing="0" cellpadding="0">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tr>
                                            <td align="left" width="30px"
                                                style="border-style:none; background: linear-gradient(to bottom,#214b80 0%,#02223c 100%); height: 35px; padding-left:5px;">
                                                <img src="img/tv.png" style=" margin-bottom: 0px;"></td>
                                            <td align="left"
                                                style="border-style:none;background: linear-gradient(to bottom,#214b80 0%,#02223c 100%); font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; font-size:16px; color:#fff; padding-left:5px">
                                                WATCH LIVE
                                            </td>
                                            <td style="background: linear-gradient(#7075b3 0%, #181f3e 100%); font-size:18px; font-weight:bold; font-family:'Lucida Sans Unicode', 'Lucida Grande', sans-serif; color:#fff; text-decoration:none; cursor:pointer; padding-bottom:3px"
                                                width="34" align="center" valign="bottom"
                                                onclick="if (!window.__cfRLUnblockHandlers) return false; javascript:togglek('trcanlitv');"
                                                data-cf-modified-49a1a8758d1ec0bbde0e32af-="">X
                                            </td>
                                        </tr>
                                        <tr>
                                            <td colspan="3">
                                                <div id="divcanliytv" width="100%" height="420"
                                                     style="text-align: center;"></div>
                                            </td>
                                        </tr>
                                    </table>
                            </div>
                        </td>
                    </tr>
                    <tr id="trcanliy" style="text-align: center; background-color: #000000; display: none">
                        <td bgcolor="#000000">
                            <div id="divcanliy"></div>
                        </td>
                    </tr>

                    <tr>
                        <td height="56" width="100%">
                            <table border="0" cellspacing="0" cellpadding="0" style="background-color: #049a09;"
                                   width="100%">
                                <tr>

                                    <td id="m0" valign="top" height="40" width="92px" class="zamanturC"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('0','ALL','1','0'); this.className='zamanturC'; m1.className='zamanturS'; m2.className='zamanturS'; m3.className='zamanturS'; m4.className='zamanturS';m5.className='zamanturS';m6.className='zamanturS';m7.className='zamanturS';togglec('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Today<br>18.10
                                    </td>

                                    <td id="m1" valign="top" width="100px" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('1','ALL','1','1'); this.className='zamanturC'; m0.className='zamanturS'; m2.className='zamanturS'; m3.className='zamanturS'; m4.className='zamanturS';m5.className='zamanturS';m6.className='zamanturS';m7.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Wednesday<br>19.10
                                    </td>

                                    <td id="m2" valign="top" width="100px" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('2','ALL','1','2'); this.className='zamanturC'; m1.className='zamanturS'; m0.className='zamanturS'; m3.className='zamanturS'; m4.className='zamanturS';m5.className='zamanturS';m6.className='zamanturS';m7.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Thursday<br>20.10
                                    </td>

                                    <td id="m3" valign="top" width="100px" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('3','ALL','1','3'); this.className='zamanturC'; m1.className='zamanturS'; m2.className='zamanturS'; m0.className='zamanturS'; m4.className='zamanturS';m5.className='zamanturS';m6.className='zamanturS';m7.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Friday<br>21.10
                                    </td>

                                    <td id="m4" valign="top" width="12%" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','ALL','1','4'); this.className='zamanturC'; m1.className='zamanturS'; m2.className='zamanturS'; m3.className='zamanturS'; m0.className='zamanturS';m7.className='zamanturS';m5.className='zamanturS';m6.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Saturday<br>22.10
                                    </td>

                                    <td id="m5" valign="top" width="12%" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('5','ALL','1','5'); this.className='zamanturC'; m1.className='zamanturS'; m2.className='zamanturS'; m3.className='zamanturS'; m0.className='zamanturS';m4.className='zamanturS';m7.className='zamanturS';m6.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Sunday<br>23.10
                                    </td>

                                    <td id="m6" valign="top" width="12%" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('6','ALL','1','6'); this.className='zamanturC'; m1.className='zamanturS'; m2.className='zamanturS'; m3.className='zamanturS'; m0.className='zamanturS';m4.className='zamanturS';m5.className='zamanturS';m7.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">Monday<br>24.10
                                    </td>

                                    <td id="m7" valign="top" width="14%" class="zamanturS"
                                        onClick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('7','ALL','1','7'); this.className='zamanturC'; m1.className='zamanturS'; m2.className='zamanturS'; m3.className='zamanturS'; m4.className='zamanturS';m5.className='zamanturS';m6.className='zamanturS';togglek('nextbets');"
                                        data-cf-modified-49a1a8758d1ec0bbde0e32af-="">All
                                    </td>

                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td width="30" align="left" valign="middle" background="images/searchbck.png"
                                        style="padding-top:10px; padding-left:6px; background: black;"><img
                                                src="imgs/search_icon.png" width="24" height="24"
                                                style="cursor:pointer;float:left"
                                                onclick="if (!window.__cfRLUnblockHandlers) return false; showonlineliste('4','ALL','1','Z',document.forms['test2'].takad.value);"
                                                data-cf-modified-49a1a8758d1ec0bbde0e32af-=""/><input type="text"
                                                                                                      id="takad"
                                                                                                      style="border-style:none; border-width:0; font-size:10pt;color: #000; font-family:Verdana; height:26px; width:200px; margin-left:10px;border-radius: 5px;"
                                                                                                      placeholder="search games"
                                                                                                      name="takad"></td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    <tr id="nextbets">
                        <td height="15">
                            <div id="txtonlinelisteNext"></div>
                        </td>
                    </tr>
                    <tr>
                        <td height="15">
                            <div id="txtonlineliste"></div>
                        </td>
                    </tr>
                </table>
            </form>
            <p>&nbsp;</p>
        </div>

        <div id="rightpanel"
             style="display: inline-block; width: 220px; min-width: 220px; vertical-align: top; height:20000px; padding-top:20px">

            <div id="Betting_Coupon_Body"
                 style=" transition: none; z-index: 800; display: block; top: 0px; bottom: auto; position: static;">
                <div id="Betting_Coupon_Body_Main"></div>
            </div>
            <script language="javascript" type="49a1a8758d1ec0bbde0e32af-text/javascript">
						<!--
							var CouponPanel = new Spry.Widget.HTMLPanel("Betting_Coupon_Body_Main", { evalScripts: true });
							CouponPanel.loadContent("bahiskuponutest.asp", { bustCache: true });
						//-->

            </script>


        </div>
    </div>


    <!-- The Modal -->
    <div id="myModal" class="modal"
         style="display: none; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0;  width: 100%;  height: 100%; overflow: auto;">

        <!-- Modal content -->
        <div class="mymodal-content">
            <div class="mymodal-header">
                <h2></h2>
            </div>
            <div class="mymodal-body">
                </br>
                <p align="center"><img src="images/ball.gif"></p>
                <p align="center">Kuponunuz onaylanıyor... Lütfen bekleyiniz...</p>
                </br>
            </div>
            <div class="mymodal-footer">
                <h3></h3>
            </div>
        </div>

    </div>


    <!-- The Modal -->
    <div id="myModalred" class="modal"
         style="display: none; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0;  width: 100%;  height: 100%; overflow: auto;">

        <!-- Modal content -->
        <div class="mymodal-content">
            <div class="mymodal-header">
                <h2></h2>
            </div>
            <div class="mymodal-body">
                </br>
                <p align="center"><img src="images/close3.png"></p>
                <p align="center">Kuponunuz ONAYLANMAMIŞTIR</p>
                </br>
            </div>
            <div class="mymodal-footer">
                <h3></h3>
            </div>
        </div>

    </div>


    <!-- The Modal -->
    <div id="myModalok" class="modalok"
         style="display: none; position: fixed; z-index: 1; padding-top: 100px; left: 0; top: 0;  width: 100%;  height: 100%; overflow: auto;">

        <!-- Modal content -->
        <div class="mymodal-content">
            <div class="mymodal-header">
                <h2></h2>
            </div>
            <div class="mymodal-body">
                </br>
                <p align="center"><img src="images/done.png"></p>
                <p align="center">Kuponunuz onaylanmıştır</p>
                </br>
            </div>
            <div class="mymodal-footer">
                <h3></h3>
            </div>
        </div>

    </div>

<script>
    $(function(){
        $("#bet-status").hide();
        $("#bets-calculator").hide();
        $(".bets-table").hide();
        request('user', function (result) {
            const response_data = result;
            $('#user-balance').text(`Balance: ${response_data.balance} {{$basic->currency}}`);
            $(".bets-table").show();
        });
        request('available_sports', function(result){
            fetchCountriesMenu(result);
            setInterval(function(){if (update && last_country_data['country_name'])
                getMatchesByCountry(last_country_data['country_name'],
                    last_country_data['write'], last_country_data['time'], true)
            }, 1000 * 60 * 10);
        });
        getDailyBets();

        $("#bet").on('click', function() {
            const bets_items = $(".bet");
            const bets = {
                amount: $("#amount").val(),
                total_bets: []
            };


            $.each(bets_items, function (index, item) {
                bets.total_bets.push(
                    $(item).data('event-info')
                )
            });

            const fast_betting_alert = $("#bet-status");

            request(`bet?items=${JSON.stringify(bets).replaceAll('\n', '')}`, function (result) {
                bets_items.remove();
                $("#bets-calculator").hide();
                fast_betting_alert.removeClass('d-none');
                fast_betting_alert.addClass('alert-success');
                fast_betting_alert.removeClass('alert-danger');
                fast_betting_alert.text(result.message);
                fast_betting_alert.show();
                fast_betting_alert.fadeOut(1000);
                $('#user-balance').text(`Balance: ${result.balance} {{$basic->currency}}`);
                getDailyBets();
                $("#amount").val(1);
            }, false, function (request, status, error) {
                fast_betting_alert.removeClass('d-none');
                fast_betting_alert.addClass('alert-danger');
                fast_betting_alert.removeClass('alert-success');
                fast_betting_alert.text(request.responseJSON.message);
                fast_betting_alert.show();
                fast_betting_alert.fadeOut(1000);
            });
        });


        function fetchCountriesMenu(response_data){
        $.each(response_data, function(index, item){
            $('#sports-menu').append($(`<div class="container-lg container-sm-fluid" id="${item}">
                                    <div class="d-flex justify-content-between border-bottom clickable main-category sublist-header bg-light">
                                         <h5>${item}</h5>
                                         <span class="fw-bold" id="teams-count-${item.replace(' ', '_')}">
                                         </span>
                                    </div>
                                    <div class="container-sm-fluid clickable subcategory mb-2" id="sub-category-${item.replace(' ', '_')}">
                                    </div>
                                </div>`));

            request(`countries?sport_name=${item}`, function(result){
                const response_data = (result);
                $('#teams-count-' + item.replace(' ', '_')).text(response_data[item.toLowerCase()]['teams_count']);
                delete response_data[item.toLowerCase()]['teams_count'];
                $.each(response_data[item.toLowerCase()], function(index, country){
                    const country_item = $(`<div class="d-flex justify-content-between align-items-center border-bottom country" data-name="${country['name']}" data-league="${country['params']['league']}" data-time="${country['params']['time']}" data-write="${country['params']['write']}">
                                                <div class="ps-1">
                                                       <img src="${country['flag']}" height="20px" width="20px">
                                                </div>
                                                <div class="text-center">
                                                    <a>${country['name']}</a>
                                                </div>
                                                <div class="pe-1 fw-bold">
                                                    ${country['teams_count']}
                                                </div>
                                            </div>`);
                    country_item.on('click', function(){
                        getMatchesByCountry($(this).data('league'), $(this).data('write'), $(this).data('time'), false, country['name']);
                    })
                    $(`#sub-category-${item.replace(' ', '_')}`).append(country_item);
                });
            })
        });
        $('.subcategory:not(:first)').hide();
        $('.main-category').on('click', function(){
            const subcategories = $('.subcategory')
            const subcategory = $(this).parent().find('.subcategory')?.first();
            $.each(subcategories, function (index, item){
                if (!$(item).is(subcategory))
                    $(item).hide(100);
            })
            subcategory?.toggle(100);
        });
    }
</script>
@endsection
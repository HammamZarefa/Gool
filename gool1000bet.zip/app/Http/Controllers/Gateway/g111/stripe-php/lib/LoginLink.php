<?php

namespace StripeJS;

/**
 * Class LoginLink
 *
 * @package StripeJS
 */
class LoginLink extends ApiResource
{

}
